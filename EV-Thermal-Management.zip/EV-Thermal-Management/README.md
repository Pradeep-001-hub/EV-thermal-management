# EV Thermal Management System — Embedded Control Layer

An embedded C controller for an integrated EV thermal management system
(battery, motor, power electronics, cabin HVAC), combining PID control,
an LSTM-based temperature predictor, a priority-based operating-mode
decision engine, and fault handling with a safety shutdown path.

## Scope: what's actually here vs. what's described in `docs/`

The design docs in `docs/` describe a much larger research program:
Python/TensorFlow LSTM training, MATLAB material simulations (PCM,
nanofluid coolants, immersion cooling), and an 800V-platform roadmap.
**None of that exists in this repository.** What's implemented and
verified is the embedded C control layer only: sensor processing, PID
loops, the LSTM *inference* engine (forward pass — not training), mode
decision, and fault handling. Treat `docs/` as the broader research
context this controller would eventually plug into, not as a
description of code that ships here.

## How to build and run

```bash
make          # builds build/ev_tms
make run      # builds and runs a 1000-cycle (100s) simulation
make test     # build + smoke test (checks exit code, scans for NaN/Inf)
make test-unit  # targeted regression test for the sensor-validation fix
make clean
```

Requires a C11 compiler (developed against GCC) and libm. No other
dependencies.

Each run appends telemetry to `tms_telemetry.csv` (one row per control
cycle) and prints a full diagnostic block to stdout every 10 cycles.

## Project structure

```
include/ev_tms.h       all structs, enums, constants, prototypes
src/
  main.c                the control loop (Init -> Read -> Validate ->
                         Update -> Predict -> DecideMode -> Execute ->
                         CheckFaults -> Log, every CONTROL_PERIOD_MS)
  tms_init.c             system/PID/LSTM-weight initialization
  tms_sensors.c          sensor read/validate + I^2R heat-generation model
  tms_lstm.c              LSTM forward pass, sequence buffer, prediction
  tms_control.c           PID update, valve/pump commands, mode decision
  tms_fault.c             fault detection/handling, safe shutdown,
                          diagnostics printing, telemetry logging
tests/
  test_sensor_validation.c   regression test (see "Bug fixed" below)
docs/
  introduction.md, evolution.md, architecture/   research-scope docs
  (context only, see Scope note above)
```

## What was fixed vs. the original upload

The original repo (see project history) had these problems, all
addressed here:

1. **Wouldn't compile at all.** Every `.c` file did
   `#include "ev_tms.h"`, but the header only existed inside a file
   named `Header file and data structures.c` — wrong name, wrong
   extension, spaces in the name. Fixed: header now lives at
   `include/ev_tms.h` and every include path was corrected.
2. **`main()` was buried inside the fault-handling file**, even though
   that file's own header comment said `FILE: tms_main.c`. Split into
   a dedicated `src/main.c`.
3. **Two declared-but-never-implemented functions:**
   `TMS_LoadLSTMWeights` and `TMS_LogState`. Both are now implemented
   (see below) and wired into `main.c`.
4. **Real logic bug in `TMS_ValidateSensors`:** when any sensor read
   out of range, it was unconditionally replaced with
   `thermal_state.T_batt_avg` — so a bad *motor* sensor would silently
   get overwritten with the *battery* temperature. Fixed with a
   per-channel `last_good_temp[]` cache in `TMSController_t`, so each
   sensor is only ever repaired with its own history. Covered by
   `tests/test_sensor_validation.c` (`make test-unit`).
5. **No build system.** Added the `Makefile` above.
6. **`.gitignore` was leftover MATLAB boilerplate.** Replaced with one
   for this C project (`build/`, `*.o`, generated CSV/weights files).

Everything else — the PID loop, LSTM forward pass, mode-decision
priority order, fault flags, safe shutdown — was already correctly
implemented in the original upload and is unchanged. Verified by
compiling all five original logic files with `-Wall -Wextra`: zero
warnings.

## `TMS_LoadLSTMWeights`

The LSTM is randomly initialized at boot (as in the original code) —
useful for exercising the control loop, but the predictions are not
meaningful until real weights are loaded. `TMS_LoadLSTMWeights()` now
reads a flat binary dump of all twelve weight/bias arrays plus the
output layer, in the order documented in `src/tms_init.c`, from
`TMS_WEIGHTS_FILE` (`lstm_weights.bin` by default). If that file isn't
present, `TMS_Init` logs a warning and falls back to the random
weights — this repository does not include a trained weights file or
the training pipeline that would produce one (that's the Python/
TensorFlow layer described in `docs/`, out of scope here).

## `TMS_LogState`

Appends one CSV row per control cycle to `TMS_LOG_FILE`
(`tms_telemetry.csv`), writing a header row on first use. Useful for
plotting a run afterward (e.g. in a spreadsheet or `pandas`) without
having to scrape the stdout diagnostic blocks.

## Known limitations (carried over from the original design, or introduced by necessity)

- The LSTM predicts against the drive cycle simulated in
  `TMS_ReadSensors` — on real hardware that function is meant to be
  replaced with actual ADC/CAN/LIN reads.
- No unit conversion/validation on the loaded weights file beyond
  "did we read the right number of floats" — a corrupt-but-right-sized
  file would load without error.
- `TMS_PIDUpdate`'s anti-windup clamp divides by `pid->Ki`; this is
  only safe because every configured controller uses `Ki > 0`. If you
  ever configure a pure PD controller (`Ki = 0`), guard that division
  before using it.
- Single-threaded, blocking `printf`/file I/O in the control loop —
  fine for this host-side simulation, not appropriate as-is for a
  hard-real-time 100 ms control period on an actual MCU.
