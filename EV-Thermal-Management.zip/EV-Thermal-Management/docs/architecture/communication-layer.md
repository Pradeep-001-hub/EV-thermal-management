CAN Bus  : 500 kbps
LIN Bus  : 19.2 kbps