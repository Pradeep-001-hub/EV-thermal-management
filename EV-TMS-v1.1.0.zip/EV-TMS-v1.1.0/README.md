# EV Integrated Thermal Management System (EV-TMS) — v1.1.0

An AI-supervised, embedded thermal controller for EV battery, motor,
inverter, and cabin HVAC cooling — unified through a single
reconfigurable thermal bus. See `docs/introduction.md` and
`docs/System architecture design/` for the full research context and
architecture rationale (carried over from v1.0.0).

This v1.1.0 pass focused on making the embedded software layer
actually deployable to a real Cortex-M target, starting from a v1.0.0
that compiled and ran a desktop simulation but wasn't hardware-ready.
Full list of changes: `docs/CHANGELOG.md`. Porting steps for real
silicon: `docs/PORTING.md`.

## Quick start (host simulation — tested)

```bash
make host && ./out/tms_host      # or: make run
make test                        # 25 unit tests
```

To use trained (rather than random/untrained) thermal predictions:

```bash
cd tools
python3 train_lstm.py --episodes 16 --episode-len 1800 --epochs 10 \
    --out ../lstm_weights.bin
cd .. && make host && ./out/tms_host
```

## Layout

```
src/
  ev_tms.h              - all structs, constants, enums
  tms_init.c            - system + PID + LSTM weight init
  tms_sensors.c         - sensor read/validate/thermal-state update
  tms_lstm.c            - LSTM forward pass + weight load/save
  tms_control.c         - PID, mode decision, actuator commands
  tms_fault.c           - fault detection/handling/diagnostics
  main.c                - control loop entry point
  hal/
    ev_hal.h             - hardware abstraction interface
    ev_hal_host.c         - desktop simulation backend (tested)
    ev_hal_stm32.c         - Cortex-M porting template (see docs/PORTING.md)
tools/
  train_lstm.py          - NumPy LSTM training pipeline
tests/
  test_tms.c              - unit tests (host only)
build/
  linker/stm32_template.ld
  startup/startup_stub.c  - generic Cortex-M skeleton
docs/
  PORTING.md, CHANGELOG.md, and the original v1.0.0 architecture docs
```

## Status

- ✅ Host build: compiles clean (`-Wall -Wextra`), runs, 25/25 tests pass.
- ✅ LSTM training pipeline: gradient-checked, trains, exports weights
  the C code loads and uses (verified — predictions land in a
  physically plausible range on the synthetic data, vs. nonsense
  from the old untrained-random-weight fallback).
- ⚠️ ARM cross-build (`make arm`): scaffolded, **not compiled** — no
  `arm-none-eabi-gcc` toolchain was available while writing this.
  `ev_hal_stm32.c` is a porting template with explicit `TODO`s, not a
  finished driver.
- ⚠️ No functional-safety (ISO 26262) review has been done. Do not
  connect real actuators/coolant hardware without independent review
  — see `docs/PORTING.md` step 7.

## License

MIT — see `LICENSE`.
