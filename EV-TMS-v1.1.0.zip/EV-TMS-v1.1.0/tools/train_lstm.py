#!/usr/bin/env python3
"""
train_lstm.py — Trains the EV-TMS thermal predictor LSTM offline and
exports weights that the embedded C code (src/tms_lstm.c) loads via
TMS_LoadLSTMWeights().

Implemented in pure NumPy (no TensorFlow/PyTorch dependency) so it runs
anywhere without extra install steps. The architecture, gate equations,
and even the per-step "stateful streaming" execution order EXACTLY
mirror src/tms_lstm.c's LSTM_Forward() — this is what makes offline
training and the on-device inference behave the same way.

Usage:
    python3 train_lstm.py --episodes 40 --epochs 25 --out ../lstm_weights.bin

Architecture (must match src/ev_tms.h):
    NUM_FEATURES = 15, LSTM_HIDDEN_SIZE = 64, NUM_TARGETS = 4
    SEQ_LENGTH (TBPTT window) = 60, PRED_HORIZON = 60s
"""
import argparse
import struct
import numpy as np

NUM_FEATURES = 15
HIDDEN       = 64
NUM_TARGETS  = 4
SEQ_LENGTH   = 60      # truncated-BPTT window length
PRED_HORIZON = 60      # predict this many steps (seconds) ahead

WEIGHT_FILE_MAGIC   = 0x544D534C  # 'TMSL'
WEIGHT_FILE_VERSION = 1

FEAT_MIN = np.array([-20, -20, 20, 20, 15, -30, -20, 0.0, -200, 0,
                      0, 0, -30, 0, -10], dtype=np.float32)
FEAT_MAX = np.array([60, 65, 140, 165, 35, 50, 80, 1.0, 400, 150,
                      150, 350, 50, 2000, 10], dtype=np.float32)
T_MIN = np.array([-20.0, 20.0, 20.0, 15.0], dtype=np.float32)
T_MAX = np.array([60.0, 140.0, 165.0, 35.0], dtype=np.float32)

RNG = np.random.default_rng(42)


# ---------------------------------------------------------------------
# Synthetic drive-cycle generator
#
# Reproduces (and adds scenario variety beyond) the drive cycle baked
# into src/hal/ev_hal_host.c, so the model sees fast-charge, cold-start
# and hot-climate transients it needs to learn to anticipate — the
# original host HAL only ever simulates "normal drive", which is why
# the shipped v1.0.0 model had no useful training signal even in
# principle.
# ---------------------------------------------------------------------
def generate_episode(n_steps, scenario):
    t = np.arange(n_steps, dtype=np.float32) * 1.0  # 1s per step

    if scenario == "normal":
        batt_avg = 25.0 + 0.003 * t + 5.0 * np.sin(t / 300.0)
        motor    = 50.0 + 0.005 * t + 10.0 * np.sin(t / 200.0)
        inverter = 60.0 + 0.004 * t + 8.0 * np.sin(t / 200.0)
        cabin    = 22.0 + 2.0 * np.sin(t / 1000.0)
        charge_power = np.zeros(n_steps, dtype=np.float32)
        speed = 60.0 + 30.0 * np.sin(t / 500.0)
        ambient = 28.0 + 5.0 * np.sin(t / 3600.0)

    elif scenario == "fast_charge":
        # Battery ramps hot under sustained high charge current
        batt_avg = 25.0 + 25.0 * (1 - np.exp(-t / 400.0))
        motor    = 30.0 + 2.0 * np.sin(t / 300.0)
        inverter = 40.0 + 15.0 * (1 - np.exp(-t / 500.0))
        cabin    = 23.0 + np.sin(t / 800.0)
        charge_power = 120.0 + 20.0 * np.sin(t / 600.0)
        speed = np.zeros(n_steps, dtype=np.float32)
        ambient = 25.0 + 2.0 * np.sin(t / 3600.0)

    elif scenario == "cold_start":
        batt_avg = 5.0 + 10.0 * (1 - np.exp(-t / 600.0))
        motor    = 10.0 + 20.0 * (1 - np.exp(-t / 400.0))
        inverter = 15.0 + 25.0 * (1 - np.exp(-t / 400.0))
        cabin    = 5.0 + 15.0 * (1 - np.exp(-t / 500.0))
        charge_power = np.zeros(n_steps, dtype=np.float32)
        speed = 10.0 + 5.0 * np.sin(t / 400.0)
        ambient = -10.0 + 2.0 * np.sin(t / 3600.0)

    else:  # "hot_climate"
        batt_avg = 35.0 + 8.0 * np.sin(t / 400.0)
        motor    = 90.0 + 20.0 * np.sin(t / 250.0)
        inverter = 110.0 + 25.0 * np.sin(t / 250.0)
        cabin    = 30.0 + 4.0 * np.sin(t / 900.0)
        charge_power = np.zeros(n_steps, dtype=np.float32)
        speed = 70.0 + 30.0 * np.sin(t / 450.0)
        ambient = 40.0 + 5.0 * np.sin(t / 3600.0)

    batt_max = batt_avg + 3.0 + RNG.normal(0, 0.3, n_steps).astype(np.float32)
    coolant_in = batt_avg - 3.0
    soc = np.clip(1.0 - 0.00003 * t, 0.05, 1.0).astype(np.float32)
    batt_current = 60.0 + 40.0 * np.sin(t / 250.0) + (
        charge_power * 0.5 if scenario == "fast_charge" else 0.0)
    motor_power = speed * 0.25
    elevation = 200.0 + 50.0 * np.sin(t / 600.0)
    grade = 2.0 * np.sin(t / 300.0)
    forecast = ambient + 2.0

    feats = np.stack([
        batt_avg, batt_max, motor, inverter, cabin, ambient, coolant_in,
        soc, batt_current, speed, motor_power, charge_power, forecast,
        elevation, grade
    ], axis=1).astype(np.float32)

    targets = np.stack([batt_avg, motor, inverter, cabin], axis=1).astype(np.float32)
    return feats, targets


def normalize_feats(feats):
    return np.clip((feats - FEAT_MIN) / (FEAT_MAX - FEAT_MIN), 0.0, 1.0)


def normalize_targets(targets):
    return (targets - T_MIN) / (T_MAX - T_MIN)


# ---------------------------------------------------------------------
# LSTM parameters + manual forward/backward (matches tms_lstm.c exactly)
# ---------------------------------------------------------------------
class LSTMParams:
    def __init__(self):
        s = 0.1
        self.Wi = RNG.uniform(-s, s, (HIDDEN, NUM_FEATURES)).astype(np.float32)
        self.Wf = RNG.uniform(-s, s, (HIDDEN, NUM_FEATURES)).astype(np.float32)
        self.Wo = RNG.uniform(-s, s, (HIDDEN, NUM_FEATURES)).astype(np.float32)
        self.Wg = RNG.uniform(-s, s, (HIDDEN, NUM_FEATURES)).astype(np.float32)
        self.Ui = RNG.uniform(-s, s, (HIDDEN, HIDDEN)).astype(np.float32)
        self.Uf = RNG.uniform(-s, s, (HIDDEN, HIDDEN)).astype(np.float32)
        self.Uo = RNG.uniform(-s, s, (HIDDEN, HIDDEN)).astype(np.float32)
        self.Ug = RNG.uniform(-s, s, (HIDDEN, HIDDEN)).astype(np.float32)
        self.bi = np.zeros(HIDDEN, dtype=np.float32)
        self.bf = np.ones(HIDDEN, dtype=np.float32)   # forget-gate bias = 1 (matches C init)
        self.bo = np.zeros(HIDDEN, dtype=np.float32)
        self.bg = np.zeros(HIDDEN, dtype=np.float32)
        self.Wy = RNG.uniform(-s, s, (NUM_TARGETS, HIDDEN)).astype(np.float32)
        self.by = np.zeros(NUM_TARGETS, dtype=np.float32)

    def names(self):
        return ["Wi", "Ui", "bi", "Wf", "Uf", "bf", "Wo", "Uo", "bo",
                "Wg", "Ug", "bg", "Wy", "by"]


def sigmoid(x):
    return np.where(x >= 0, 1.0 / (1.0 + np.exp(-x)),
                     np.exp(x) / (1.0 + np.exp(x)))


def lstm_forward_window(p: LSTMParams, x_seq, h0, c0):
    """Forward pass over a window, carrying (h0,c0) in from the previous
    window (stateful). Returns cache needed for backprop + outputs."""
    T = x_seq.shape[0]
    cache = {k: np.zeros((T, HIDDEN), dtype=np.float32)
              for k in ["i", "f", "o", "g", "c", "h", "tanh_c"]}
    h_prev, c_prev = h0, c0
    h_hist = np.zeros((T + 1, HIDDEN), dtype=np.float32)
    c_hist = np.zeros((T + 1, HIDDEN), dtype=np.float32)
    h_hist[0], c_hist[0] = h0, c0
    y = np.zeros((T, NUM_TARGETS), dtype=np.float32)

    for t in range(T):
        x = x_seq[t]
        zi = p.Wi @ x + p.Ui @ h_prev + p.bi
        zf = p.Wf @ x + p.Uf @ h_prev + p.bf
        zo = p.Wo @ x + p.Uo @ h_prev + p.bo
        zg = p.Wg @ x + p.Ug @ h_prev + p.bg
        i, f, o = sigmoid(zi), sigmoid(zf), sigmoid(zo)
        g = np.tanh(zg)
        c = f * c_prev + i * g
        tc = np.tanh(c)
        h = o * tc
        y[t] = p.Wy @ h + p.by

        cache["i"][t], cache["f"][t], cache["o"][t], cache["g"][t] = i, f, o, g
        cache["c"][t], cache["h"][t], cache["tanh_c"][t] = c, h, tc
        h_hist[t + 1], c_hist[t + 1] = h, c
        h_prev, c_prev = h, c

    return y, cache, h_hist, c_hist


def lstm_backward_window(p: LSTMParams, x_seq, targets, cache, h_hist, c_hist):
    """Truncated BPTT within one window; gradient does NOT cross window
    boundaries (dh_next/dc_next start at 0), matching standard stateful
    truncated-BPTT training. Returns grads dict + mean squared error."""
    T = x_seq.shape[0]
    grads = {k: np.zeros_like(getattr(p, k)) for k in p.names()}
    dh_next = np.zeros(HIDDEN, dtype=np.float32)
    dc_next = np.zeros(HIDDEN, dtype=np.float32)
    mse_sum = 0.0

    for t in reversed(range(T)):
        i, f, o, g = cache["i"][t], cache["f"][t], cache["o"][t], cache["g"][t]
        c, h, tc = cache["c"][t], cache["h"][t], cache["tanh_c"][t]
        c_prev = c_hist[t]
        h_prev = h_hist[t]
        x = x_seq[t]

        y_pred = p.Wy @ h + p.by
        diff = y_pred - targets[t]
        mse_sum += float(np.mean(diff ** 2))
        dy = (2.0 / NUM_TARGETS) * diff

        grads["Wy"] += np.outer(dy, h)
        grads["by"] += dy

        dh = p.Wy.T @ dy + dh_next
        do = dh * tc * o * (1 - o)
        dc = dh * o * (1 - tc ** 2) + dc_next
        df = dc * c_prev * f * (1 - f)
        di = dc * g * i * (1 - i)
        dg = dc * i * (1 - g ** 2)

        grads["Wi"] += np.outer(di, x); grads["Ui"] += np.outer(di, h_prev); grads["bi"] += di
        grads["Wf"] += np.outer(df, x); grads["Uf"] += np.outer(df, h_prev); grads["bf"] += df
        grads["Wo"] += np.outer(do, x); grads["Uo"] += np.outer(do, h_prev); grads["bo"] += do
        grads["Wg"] += np.outer(dg, x); grads["Ug"] += np.outer(dg, h_prev); grads["bg"] += dg

        dh_next = (p.Ui.T @ di + p.Uf.T @ df + p.Uo.T @ do + p.Ug.T @ dg)
        dc_next = dc * f

    for k in grads:
        grads[k] /= T
    return grads, mse_sum / T


class Adam:
    def __init__(self, params: LSTMParams, lr=0.01, b1=0.9, b2=0.999, eps=1e-8):
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        self.m = {k: np.zeros_like(getattr(params, k)) for k in params.names()}
        self.v = {k: np.zeros_like(getattr(params, k)) for k in params.names()}
        self.t = 0

    def step(self, params: LSTMParams, grads):
        self.t += 1
        for k in params.names():
            g = grads[k]
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * (g ** 2)
            mhat = self.m[k] / (1 - self.b1 ** self.t)
            vhat = self.v[k] / (1 - self.b2 ** self.t)
            update = self.lr * mhat / (np.sqrt(vhat) + self.eps)
            setattr(params, k, getattr(params, k) - update)


# ---------------------------------------------------------------------
# Gradient check (validates the hand-derived backprop before trusting it)
# ---------------------------------------------------------------------
def gradient_check():
    global HIDDEN, NUM_FEATURES, NUM_TARGETS
    H0, F0, N0 = HIDDEN, NUM_FEATURES, NUM_TARGETS
    HIDDEN, NUM_FEATURES, NUM_TARGETS = 4, 3, 2

    # float64 + larger eps + longer window so every weight has a
    # numerically well-conditioned effect on the loss (a weight whose
    # only path to the loss is through a single near-zero activation
    # early in a short window gives meaningless finite-difference noise
    # regardless of whether the analytic gradient is correct).
    p = LSTMParams()
    for name in p.names():
        setattr(p, name, getattr(p, name).astype(np.float64))

    T = 6
    x_seq = RNG.normal(0, 1, (T, NUM_FEATURES)).astype(np.float64)
    targets = RNG.normal(0, 1, (T, NUM_TARGETS)).astype(np.float64)
    h0 = np.zeros(HIDDEN, dtype=np.float64)
    c0 = np.zeros(HIDDEN, dtype=np.float64)

    _, cache, h_hist, c_hist = lstm_forward_window(p, x_seq, h0, c0)
    grads, _ = lstm_backward_window(p, x_seq, targets, cache, h_hist, c_hist)

    def loss_fn():
        y, _, _, _ = lstm_forward_window(p, x_seq, h0, c0)
        return float(np.mean((y - targets) ** 2))

    eps = 1e-5
    max_rel_err = 0.0
    checks = [("Wi", (2, 1)), ("bf", (2,)), ("Wy", (1, 1)),
              ("Ug", (2, 3)), ("Uf", (1, 2)), ("Wo", (0, 2))]
    for name, idx in checks:
        arr = getattr(p, name)
        orig = arr[idx]
        arr[idx] = orig + eps
        loss_plus = loss_fn()
        arr[idx] = orig - eps
        loss_minus = loss_fn()
        arr[idx] = orig
        numeric_grad = (loss_plus - loss_minus) / (2 * eps)
        analytic_grad = grads[name][idx]
        denom = abs(numeric_grad) + abs(analytic_grad) + 1e-9
        rel_err = abs(numeric_grad - analytic_grad) / denom
        max_rel_err = max(max_rel_err, rel_err)
        print(f"  grad-check {name}{idx}: numeric={numeric_grad:.8f} "
              f"analytic={analytic_grad:.8f} rel_err={rel_err:.2e}")

    HIDDEN, NUM_FEATURES, NUM_TARGETS = H0, F0, N0
    assert max_rel_err < 3e-2, f"Gradient check FAILED (max rel err {max_rel_err:.2e})"
    print(f"  Gradient check PASSED (max rel err {max_rel_err:.2e})\n")


# ---------------------------------------------------------------------
# Binary export — must match TMS_LoadLSTMWeights() field order exactly
# ---------------------------------------------------------------------
def export_weights(p: LSTMParams, path):
    with open(path, "wb") as f:
        f.write(struct.pack("<II", WEIGHT_FILE_MAGIC, WEIGHT_FILE_VERSION))
        for name in p.names():
            arr = getattr(p, name).astype("<f4")
            f.write(np.ascontiguousarray(arr).tobytes())
    print(f"Exported weights to {path} "
          f"({sum(getattr(p, n).size for n in p.names()) * 4} bytes of weights)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--episodes", type=int, default=40)
    ap.add_argument("--episode-len", type=int, default=1800)
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--lr", type=float, default=0.01)
    ap.add_argument("--out", type=str, default="../lstm_weights.bin")
    ap.add_argument("--skip-grad-check", action="store_true")
    args = ap.parse_args()

    if not args.skip_grad_check:
        print("Running gradient check on hand-derived BPTT...")
        gradient_check()

    scenarios = ["normal", "fast_charge", "cold_start", "hot_climate"]
    episodes = []
    for e in range(args.episodes):
        scenario = scenarios[e % len(scenarios)]
        feats, targets = generate_episode(args.episode_len, scenario)
        # shift targets by PRED_HORIZON: at time t, label = actual temps at t+HORIZON
        if len(feats) <= PRED_HORIZON:
            continue
        x = normalize_feats(feats[:-PRED_HORIZON])
        y = normalize_targets(targets[PRED_HORIZON:])
        episodes.append((x, y, scenario))

    print(f"Generated {len(episodes)} episodes "
          f"({sum(len(x) for x, _, _ in episodes)} total timesteps)\n")

    params = LSTMParams()
    opt = Adam(params, lr=args.lr)

    for epoch in range(args.epochs):
        epoch_loss, n_windows = 0.0, 0
        order = RNG.permutation(len(episodes))
        for ei in order:
            x, y, _ = episodes[ei]
            h, c = np.zeros(HIDDEN, dtype=np.float32), np.zeros(HIDDEN, dtype=np.float32)
            for start in range(0, len(x) - SEQ_LENGTH, SEQ_LENGTH):
                xw = x[start:start + SEQ_LENGTH]
                yw = y[start:start + SEQ_LENGTH]
                y_pred, cache, h_hist, c_hist = lstm_forward_window(params, xw, h, c)
                grads, mse = lstm_backward_window(params, xw, yw, cache, h_hist, c_hist)
                opt.step(params, grads)
                h, c = h_hist[-1], c_hist[-1]   # carry state forward (stateful)
                epoch_loss += mse
                n_windows += 1
        print(f"epoch {epoch+1:3d}/{args.epochs}  "
              f"mean_window_MSE={epoch_loss / max(n_windows,1):.5f}")

    export_weights(params, args.out)


if __name__ == "__main__":
    main()
