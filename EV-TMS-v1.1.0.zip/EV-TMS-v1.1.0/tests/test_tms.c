/* ============================================================
   FILE: test_tms.c
   Unit tests for EV-TMS core logic (host build only).
   Run with: make test
   ============================================================ */
#include "ev_tms.h"
#include <assert.h>

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, msg) do { \
    if (cond) { g_pass++; } \
    else { g_fail++; printf("  [FAIL] %s (line %d)\n", msg, __LINE__); } \
} while (0)

#define CHECK_NEAR(a, b, tol, msg) CHECK(fabsf((a)-(b)) < (tol), msg)

/* ── PID: no divide-by-zero when Ki == 0 (v1.0.0 bug) ────── */
static void test_pid_ki_zero_no_crash(void)
{
    PIDController_t pid;
    TMS_InitPID(&pid, 1.0f, 0.0f, 0.0f, 25.0f, 0.0f, 255.0f, 0.1f);
    float out = TMS_PIDUpdate(&pid, 20.0f);
    CHECK(!isnan(out) && !isinf(out), "PID with Ki=0 must not produce NaN/Inf");
    CHECK_NEAR(out, 5.0f, 0.01f, "PID with Ki=0,Kd=0 should equal Kp*error");
}

/* ── PID: basic proportional response direction ──────────── */
static void test_pid_proportional_direction(void)
{
    PIDController_t pid;
    TMS_InitPID(&pid, 2.0f, 0.0f, 0.0f, 30.0f, 0.0f, 255.0f, 0.1f);
    float out_below = TMS_PIDUpdate(&pid, 20.0f); /* error = +10 */
    TMS_InitPID(&pid, 2.0f, 0.0f, 0.0f, 30.0f, 0.0f, 255.0f, 0.1f);
    float out_above = TMS_PIDUpdate(&pid, 40.0f); /* error = -10 */
    CHECK(out_below > out_above, "PID output should be higher when measured < setpoint");
}

/* ── PID: output clamps to [min,max] ─────────────────────── */
static void test_pid_output_clamp(void)
{
    PIDController_t pid;
    TMS_InitPID(&pid, 100.0f, 0.0f, 0.0f, 100.0f, 0.0f, 50.0f, 0.1f);
    float out = TMS_PIDUpdate(&pid, 0.0f); /* huge error, should clamp */
    CHECK(out <= 50.0f && out >= 0.0f, "PID output must respect output_min/max clamp");
}

/* ── Sigmoid/tanh sanity ──────────────────────────────────── */
static void test_activations(void)
{
    CHECK_NEAR(LSTM_Sigmoid(0.0f), 0.5f, 1e-5f, "sigmoid(0) == 0.5");
    CHECK(LSTM_Sigmoid(100.0f) > 0.999f, "sigmoid(large) -> ~1");
    CHECK(LSTM_Sigmoid(-100.0f) < 0.001f, "sigmoid(-large) -> ~0");
    CHECK_NEAR(LSTM_Tanh(0.0f), 0.0f, 1e-5f, "tanh(0) == 0");
    CHECK(!isnan(LSTM_Sigmoid(-1000.0f)), "sigmoid must not NaN on very negative input");
}

/* ── Mode decision priority order ────────────────────────── */
static TMSController_t make_tms(void)
{
    TMSController_t tms;
    memset(&tms, 0, sizeof(tms));
    tms.thermal_state.T_batt_avg = 25.0f;
    tms.thermal_state.T_batt_max = 28.0f;
    tms.thermal_state.T_motor    = 60.0f;
    tms.thermal_state.T_cabin    = 22.0f;
    tms.sensors.ambient_temp     = 25.0f;
    tms.sensors.vehicle_speed    = 60.0f;
    tms.sensors.charge_power     = 0.0f;
    tms.lstm_primed = false;
    return tms;
}

static void test_mode_thermal_runaway_top_priority(void)
{
    TMSController_t tms = make_tms();
    tms.thermal_state.T_batt_max = 85.0f;    /* > runaway threshold */
    tms.sensors.charge_power = 200.0f;        /* also fast-charge condition true */
    OperatingMode_t m = TMS_DecideMode(&tms);
    CHECK(m == MODE_THERMAL_RUNAWAY,
          "Thermal runaway must win over fast-charge (safety first)");
}

static void test_mode_fast_charge(void)
{
    TMSController_t tms = make_tms();
    tms.sensors.charge_power = 100.0f;
    CHECK(TMS_DecideMode(&tms) == MODE_FAST_CHARGE, "High charge power -> fast charge mode");
}

static void test_mode_cold_start(void)
{
    TMSController_t tms = make_tms();
    tms.thermal_state.T_batt_avg = 5.0f;
    tms.sensors.vehicle_speed = 0.0f;
    CHECK(TMS_DecideMode(&tms) == MODE_COLD_START, "Cold battery + parked -> cold start");
}

static void test_mode_hot_climate(void)
{
    TMSController_t tms = make_tms();
    tms.sensors.ambient_temp = 40.0f;
    CHECK(TMS_DecideMode(&tms) == MODE_HOT_CLIMATE, "Hot ambient -> hot climate mode");
}

static void test_mode_normal_default(void)
{
    TMSController_t tms = make_tms();
    CHECK(TMS_DecideMode(&tms) == MODE_NORMAL_DRIVE, "Nominal conditions -> normal drive");
}

static void test_mode_predictive_requires_priming(void)
{
    TMSController_t tms = make_tms();
    tms.lstm_primed = false;
    tms.T_batt_pred = 100.0f; /* would trigger predictive cool if trusted */
    CHECK(TMS_DecideMode(&tms) != MODE_PREDICTIVE_COOL,
          "Un-primed LSTM prediction must not be acted on");
    tms.lstm_primed = true;
    CHECK(TMS_DecideMode(&tms) == MODE_PREDICTIVE_COOL,
          "Primed LSTM prediction above threshold -> predictive cool");
}

/* ── Fault detection ──────────────────────────────────────── */
static void test_fault_battery_overheat(void)
{
    TMSController_t tms = make_tms();
    tms.thermal_state.T_batt_max = 60.0f; /* > BATT_TEMP_CRITICAL (55) */
    tms.sensors.flow_rate[0] = tms.sensors.flow_rate[1] =
        tms.sensors.flow_rate[2] = tms.sensors.flow_rate[3] = 8.0f;
    TMS_CheckFaults(&tms);
    CHECK((tms.fault_flags & FAULT_BATT_OVERHEAT) != 0,
          "T_batt_max above critical must raise FAULT_BATT_OVERHEAT");
}

static void test_fault_low_flow(void)
{
    TMSController_t tms = make_tms();
    tms.sensors.flow_rate[0] = 0.5f; /* < 2.0 L/min threshold */
    tms.sensors.flow_rate[1] = tms.sensors.flow_rate[2] =
        tms.sensors.flow_rate[3] = 8.0f;
    TMS_CheckFaults(&tms);
    CHECK((tms.fault_flags & FAULT_COOLANT_LOW_FLOW) != 0,
          "Low flow rate must raise FAULT_COOLANT_LOW_FLOW");
}

/* ── Weight save/load round-trip ──────────────────────────── */
static void test_weight_roundtrip(void)
{
    LSTMNetwork_t net_out, net_in;
    memset(&net_out, 0, sizeof(net_out));
    memset(&net_in, 0, sizeof(net_in));

    for (int i = 0; i < LSTM_HIDDEN_SIZE; i++) {
        net_out.bi[i] = (float)i * 0.01f;
        net_out.bf[i] = 1.0f;
        for (int j = 0; j < NUM_FEATURES; j++)
            net_out.Wi[i][j] = (float)(i + j) * 0.001f;
    }
    net_out.Wy[0][0] = 3.14159f;

    CHECK(TMS_SaveLSTMWeights(&net_out, "/tmp/test_lstm_roundtrip.bin"),
          "Save should succeed");
    CHECK(TMS_LoadLSTMWeights(&net_in, "/tmp/test_lstm_roundtrip.bin"),
          "Load should succeed");
    CHECK_NEAR(net_in.Wy[0][0], 3.14159f, 1e-5f, "Wy round-trips exactly");
    CHECK_NEAR(net_in.bi[10], net_out.bi[10], 1e-6f, "bi round-trips exactly");
    CHECK_NEAR(net_in.Wi[5][7], net_out.Wi[5][7], 1e-6f, "Wi round-trips exactly");
    CHECK(net_in.weights_loaded == true, "weights_loaded flag set on successful load");
}

static void test_weight_load_missing_file_fails_gracefully(void)
{
    LSTMNetwork_t net;
    memset(&net, 0, sizeof(net));
    bool ok = TMS_LoadLSTMWeights(&net, "/tmp/definitely_does_not_exist.bin");
    CHECK(!ok, "Loading a missing weight file should return false, not crash");
}

int main(void)
{
    printf("Running EV-TMS unit tests...\n\n");

    test_pid_ki_zero_no_crash();
    test_pid_proportional_direction();
    test_pid_output_clamp();
    test_activations();
    test_mode_thermal_runaway_top_priority();
    test_mode_fast_charge();
    test_mode_cold_start();
    test_mode_hot_climate();
    test_mode_normal_default();
    test_mode_predictive_requires_priming();
    test_fault_battery_overheat();
    test_fault_low_flow();
    test_weight_roundtrip();
    test_weight_load_missing_file_fails_gracefully();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
