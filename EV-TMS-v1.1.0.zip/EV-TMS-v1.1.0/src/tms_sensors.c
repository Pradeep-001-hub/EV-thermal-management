/* ============================================================
   FILE: tms_sensors.c
   EV Thermal Management — Sensor Reading & Processing
   v1.1.0: now goes through the HAL instead of hardcoding a
   simulated drive cycle inline, so this file is identical on
   host and target builds.
   ============================================================ */

#include "ev_tms.h"

/* ── Read All Sensors via HAL ────────────────────────────── */
void TMS_ReadSensors(TMSController_t *tms)
{
    SensorData_t *s = &tms->sensors;

    s->timestamp_ms = HAL_GetTick();

    for (int i = 0; i < NUM_TEMP_SENSORS; i++)
        s->temperature[i] = HAL_ReadTempSensor((uint8_t)i);

    for (int i = 0; i < NUM_PRESSURE_SENSORS; i++)
        s->pressure[i] = HAL_ReadPressureSensor((uint8_t)i);

    for (int i = 0; i < NUM_FLOW_SENSORS; i++)
        s->flow_rate[i] = HAL_ReadFlowSensor((uint8_t)i);

    s->ambient_temp     = HAL_ReadAmbientTemp();
    s->ambient_humidity = HAL_ReadAmbientHumidity();
    s->solar_load       = HAL_ReadSolarLoad();
    s->vehicle_speed    = HAL_ReadVehicleSpeed();
    s->battery_current  = HAL_ReadBatteryCurrent();
    s->battery_voltage  = HAL_ReadBatteryVoltage();
    s->soc              = HAL_ReadSOC();
    s->motor_power      = HAL_ReadMotorPower();
    s->charge_power     = HAL_ReadChargePower();
    s->gps_elevation    = HAL_ReadGPSElevation();
    s->gps_grade        = HAL_ReadGPSGrade();
    s->temp_forecast    = HAL_ReadWeatherForecastTemp();
}

/* ── Update Thermal State from Sensor Readings ───────────── */
void TMS_UpdateThermalState(TMSController_t *tms)
{
    SensorData_t   *s  = &tms->sensors;
    ThermalState_t *ts = &tms->thermal_state;

    ts->T_batt_avg    = s->temperature[TS_BATT_AVG];
    ts->T_batt_max    = s->temperature[TS_BATT_MAX];
    ts->T_batt_min    = s->temperature[TS_BATT_MIN];
    ts->T_batt_delta  = ts->T_batt_max - ts->T_batt_min;
    ts->T_motor       = s->temperature[TS_MOTOR];
    ts->T_inverter    = s->temperature[TS_INVERTER];
    ts->T_cabin       = s->temperature[TS_CABIN];
    ts->T_coolant_in  = s->temperature[TS_COOLANT_IN];
    ts->T_coolant_out = s->temperature[TS_COOLANT_OUT];

    /* Estimate heat generation using I²R model.
       NOTE: Q_inv_gen reuses motor current as a proxy — SiC
       inverter losses are switching-loss dominated, not pure
       I²R. This remains a simplification (flagged, not fixed,
       since a real switching-loss model needs Vds/Id/fsw curves
       from the SiC module datasheet). */
    float R_cell  = 0.002f;  /* 2 mΩ per cell (typical Li-ion) */
    float R_motor = 0.05f;   /* 50 mΩ motor winding resistance */
    float R_inv   = 0.001f;  /* 1 mΩ inverter equivalent (approx.) */

    ts->Q_batt_gen  = TMS_CalcHeatGeneration(s->battery_current, R_cell);
    ts->Q_motor_gen = TMS_CalcHeatGeneration(
                          s->motor_power * 1000.0f / 380.0f, R_motor);
    ts->Q_inv_gen   = TMS_CalcHeatGeneration(
                          s->motor_power * 1000.0f / 380.0f, R_inv);
}

/* ── Heat Generation: I²R Model ──────────────────────────── */
float TMS_CalcHeatGeneration(float current, float resistance)
{
    return current * current * resistance;  /* P = I²R (Watts) */
}

/* ── Sensor Validation ───────────────────────────────────── */
void TMS_ValidateSensors(TMSController_t *tms)
{
    SensorData_t *s = &tms->sensors;

    /* Check for out-of-range temperature readings */
    for (int i = 0; i < NUM_TEMP_SENSORS; i++) {
        if (s->temperature[i] < -40.0f || s->temperature[i] > 200.0f) {
            tms->fault_flags |= FAULT_SENSOR_FAILURE;
            HAL_Log("[WARN] Sensor %d out of range: %.1f C",
                    i, s->temperature[i]);
            /* Replace with last known good value */
            s->temperature[i] = tms->thermal_state.T_batt_avg;
        }
    }

    /* Check flow sensors */
    for (int i = 0; i < NUM_FLOW_SENSORS; i++) {
        if (s->flow_rate[i] < 1.0f) {
            tms->fault_flags |= FAULT_COOLANT_LOW_FLOW;
            HAL_Log("[WARN] Low flow on circuit %d: %.2f L/min",
                    i, s->flow_rate[i]);
        }
    }

    /* SOC range check */
    if (s->soc < 0.0f || s->soc > 1.0f) {
        s->soc = (s->soc < 0.0f) ? 0.0f : 1.0f;
    }
}
