/* ============================================================
   FILE: tms_lstm.c
   EV Thermal Management — LSTM Forward Pass + Weight I/O
   Real-time temperature prediction engine

   v1.1.0 fix: the original TMS_RunLSTMPrediction() called
   LSTM_ResetState() then replayed all SEQ_LENGTH=60 buffered
   timesteps through LSTM_Forward() EVERY control cycle (every
   100ms) — that's 60x the necessary matmul work per cycle,
   almost certainly too slow for a 100ms budget on a Cortex-M.

   Fix: the LSTM hidden/cell state IS a running summary of
   everything it has seen, so we now run ONE incremental
   LSTM_Forward() step per new sample (stateful streaming
   inference) instead of replaying the whole window. State is
   reset only at TMS_Init() / LSTM_ResetState(), never per-cycle.
   This is O(1) per cycle instead of O(SEQ_LENGTH), and matches
   how the companion training script (tools/train_lstm.py) trains
   the network: with state carried forward across truncated-BPTT
   windows ("stateful" training), so inference behavior matches
   training behavior.

   The circular sequence_buffer is now used only to (a) gate the
   warm-up period before the first prediction is trusted, and
   (b) provide a replay buffer for offline diagnostics/logging —
   it is no longer replayed for every online prediction.
   ============================================================ */

#include "ev_tms.h"

/* ── Activation: Sigmoid ─────────────────────────────────── */
float LSTM_Sigmoid(float x)
{
    /* Numerically stable sigmoid */
    if (x >= 0.0f)
        return 1.0f / (1.0f + expf(-x));
    else {
        float ex = expf(x);
        return ex / (1.0f + ex);
    }
}

/* ── Activation: Tanh ────────────────────────────────────── */
float LSTM_Tanh(float x)
{
    return tanhf(x);
}

/* ── LSTM Single Timestep Forward Pass (stateful) ────────── */
void LSTM_Forward(LSTMNetwork_t *net,
                  const float input[NUM_FEATURES],
                  float output[NUM_TARGETS])
{
    float i_gate[LSTM_HIDDEN_SIZE];  /* Input gate */
    float f_gate[LSTM_HIDDEN_SIZE];  /* Forget gate */
    float o_gate[LSTM_HIDDEN_SIZE];  /* Output gate */
    float g_gate[LSTM_HIDDEN_SIZE];  /* Cell gate */
    float c_new[LSTM_HIDDEN_SIZE];   /* New cell state */
    float h_new[LSTM_HIDDEN_SIZE];   /* New hidden state */

    for (int j = 0; j < LSTM_HIDDEN_SIZE; j++) {

        float sum_i = net->bi[j];
        float sum_f = net->bf[j];
        float sum_o = net->bo[j];
        float sum_g = net->bg[j];

        for (int k = 0; k < NUM_FEATURES; k++) {
            sum_i += net->Wi[j][k] * input[k];
            sum_f += net->Wf[j][k] * input[k];
            sum_o += net->Wo[j][k] * input[k];
            sum_g += net->Wg[j][k] * input[k];
        }

        for (int k = 0; k < LSTM_HIDDEN_SIZE; k++) {
            sum_i += net->Ui[j][k] * net->h[k];
            sum_f += net->Uf[j][k] * net->h[k];
            sum_o += net->Uo[j][k] * net->h[k];
            sum_g += net->Ug[j][k] * net->h[k];
        }

        i_gate[j] = LSTM_Sigmoid(sum_i);
        f_gate[j] = LSTM_Sigmoid(sum_f);
        o_gate[j] = LSTM_Sigmoid(sum_o);
        g_gate[j] = LSTM_Tanh(sum_g);
    }

    for (int j = 0; j < LSTM_HIDDEN_SIZE; j++) {
        c_new[j] = f_gate[j] * net->c[j] + i_gate[j] * g_gate[j];
        h_new[j] = o_gate[j] * LSTM_Tanh(c_new[j]);
    }

    memcpy(net->c, c_new, sizeof(float) * LSTM_HIDDEN_SIZE);
    memcpy(net->h, h_new, sizeof(float) * LSTM_HIDDEN_SIZE);

    for (int i = 0; i < NUM_TARGETS; i++) {
        float sum = net->by[i];
        for (int j = 0; j < LSTM_HIDDEN_SIZE; j++)
            sum += net->Wy[i][j] * net->h[j];
        output[i] = sum;  /* Raw output (de-normalize externally) */
    }
}

/* ── Feature normalization (shared by streaming + training) ─ */
void TMS_NormalizeFeatures(float features[NUM_FEATURES])
{
    static const float feat_min[NUM_FEATURES] = {
        -20,  -20,  20,   20,   15,
        -30,  -20,  0.0,  -200, 0,
         0,    0,  -30,   0,   -10
    };
    static const float feat_max[NUM_FEATURES] = {
         60,   65,  140,  165,  35,
         50,   80,  1.0,  400,  150,
         150,  350,  50,  2000,  10
    };

    for (int i = 0; i < NUM_FEATURES; i++) {
        float range = feat_max[i] - feat_min[i];
        if (range > 0.0f)
            features[i] = (features[i] - feat_min[i]) / range;
        features[i] = fmaxf(0.0f, fminf(1.0f, features[i]));
    }
}

/* ── Update Sequence Buffer (sliding window) ─────────────── */
void TMS_UpdateSequenceBuffer(TMSController_t *tms)
{
    SensorData_t *s = &tms->sensors;

    float features[NUM_FEATURES];
    features[FEAT_T_BATT_AVG]   = s->temperature[TS_BATT_AVG];
    features[FEAT_T_BATT_MAX]   = s->temperature[TS_BATT_MAX];
    features[FEAT_T_MOTOR]      = s->temperature[TS_MOTOR];
    features[FEAT_T_INVERTER]   = s->temperature[TS_INVERTER];
    features[FEAT_T_CABIN]      = s->temperature[TS_CABIN];
    features[FEAT_T_AMBIENT]    = s->ambient_temp;
    features[FEAT_T_COOLANT_IN] = s->temperature[TS_COOLANT_IN];
    features[FEAT_SOC]          = s->soc;
    features[FEAT_I_BATT]       = s->battery_current;
    features[FEAT_V_VEHICLE]    = s->vehicle_speed;
    features[FEAT_P_MOTOR]      = s->motor_power;
    features[FEAT_Q_CHARGE]     = s->charge_power;
    features[FEAT_T_FORECAST]   = s->temp_forecast;
    features[FEAT_ELEVATION]    = s->gps_elevation;
    features[FEAT_GRADE]        = s->gps_grade;

    TMS_NormalizeFeatures(features);

    int idx = tms->sequence_index % SEQ_LENGTH;
    memcpy(tms->sequence_buffer[idx], features, sizeof(float) * NUM_FEATURES);
    tms->sequence_index++;
    if (tms->sequence_index >= SEQ_LENGTH)
        tms->lstm_primed = true;
}

/* ── Run LSTM Prediction (stateful, O(1) per cycle) ──────── */
void TMS_RunLSTMPrediction(TMSController_t *tms)
{
    /* Don't trust/emit predictions until the state has actually
       been warmed up with a full window's worth of history. The
       state has still been updated every cycle since tick 0 —
       we just don't act on the output until it's warmed up. */
    int newest = (tms->sequence_index - 1 + SEQ_LENGTH) % SEQ_LENGTH;
    float output[NUM_TARGETS];

    LSTM_Forward(&tms->lstm_net, tms->sequence_buffer[newest], output);

    if (!tms->lstm_primed) return;

    static const float T_min[NUM_TARGETS] = { -20.0f,  20.0f,  20.0f,  15.0f };
    static const float T_max[NUM_TARGETS] = {  60.0f, 140.0f, 165.0f,  35.0f };

    for (int i = 0; i < NUM_TARGETS; i++)
        output[i] = output[i] * (T_max[i] - T_min[i]) + T_min[i];

    tms->T_batt_pred  = output[TGT_T_BATT];
    tms->T_motor_pred = output[TGT_T_MOTOR];
    tms->T_inv_pred   = output[TGT_T_INV];
    tms->T_cabin_pred = output[TGT_T_CABIN];
}

/* ── Weight I/O ───────────────────────────────────────────
   Binary layout is field-by-field (not a raw struct dump) so
   it's independent of compiler struct padding/alignment and
   matches tools/train_lstm.py's export_weights() byte-for-byte.
   Layout: magic(u32) version(u32) then each array below, in
   this exact order, as raw little-endian float32.
   ──────────────────────────────────────────────────────────*/
typedef struct { uint32_t magic; uint32_t version; } WeightFileHeader_t;

static bool write_all(FILE *f, const void *p, size_t n)
{
    return fwrite(p, 1, n, f) == n;
}
static bool read_all(FILE *f, void *p, size_t n)
{
    return fread(p, 1, n, f) == n;
}

bool TMS_SaveLSTMWeights(const LSTMNetwork_t *net, const char *filepath)
{
    FILE *f = fopen(filepath, "wb");
    if (!f) return false;

    WeightFileHeader_t hdr = { WEIGHT_FILE_MAGIC, WEIGHT_FILE_VERSION };
    bool ok = write_all(f, &hdr, sizeof(hdr));

    ok = ok && write_all(f, net->Wi, sizeof(net->Wi));
    ok = ok && write_all(f, net->Ui, sizeof(net->Ui));
    ok = ok && write_all(f, net->bi, sizeof(net->bi));
    ok = ok && write_all(f, net->Wf, sizeof(net->Wf));
    ok = ok && write_all(f, net->Uf, sizeof(net->Uf));
    ok = ok && write_all(f, net->bf, sizeof(net->bf));
    ok = ok && write_all(f, net->Wo, sizeof(net->Wo));
    ok = ok && write_all(f, net->Uo, sizeof(net->Uo));
    ok = ok && write_all(f, net->bo, sizeof(net->bo));
    ok = ok && write_all(f, net->Wg, sizeof(net->Wg));
    ok = ok && write_all(f, net->Ug, sizeof(net->Ug));
    ok = ok && write_all(f, net->bg, sizeof(net->bg));
    ok = ok && write_all(f, net->Wy, sizeof(net->Wy));
    ok = ok && write_all(f, net->by, sizeof(net->by));

    fclose(f);
    return ok;
}

bool TMS_LoadLSTMWeights(LSTMNetwork_t *net, const char *filepath)
{
    if (net == NULL || filepath == NULL) return false;

    FILE *f = fopen(filepath, "rb");
    if (!f) {
        HAL_Log("[LSTM] Weight file '%s' not found — keeping "
                "untrained/random weights", filepath);
        return false;
    }

    WeightFileHeader_t hdr;
    bool ok = read_all(f, &hdr, sizeof(hdr));
    if (!ok || hdr.magic != WEIGHT_FILE_MAGIC || hdr.version != WEIGHT_FILE_VERSION) {
        HAL_Log("[LSTM] Weight file '%s' bad header — rejecting", filepath);
        fclose(f);
        return false;
    }

    ok = ok && read_all(f, net->Wi, sizeof(net->Wi));
    ok = ok && read_all(f, net->Ui, sizeof(net->Ui));
    ok = ok && read_all(f, net->bi, sizeof(net->bi));
    ok = ok && read_all(f, net->Wf, sizeof(net->Wf));
    ok = ok && read_all(f, net->Uf, sizeof(net->Uf));
    ok = ok && read_all(f, net->bf, sizeof(net->bf));
    ok = ok && read_all(f, net->Wo, sizeof(net->Wo));
    ok = ok && read_all(f, net->Uo, sizeof(net->Uo));
    ok = ok && read_all(f, net->bo, sizeof(net->bo));
    ok = ok && read_all(f, net->Wg, sizeof(net->Wg));
    ok = ok && read_all(f, net->Ug, sizeof(net->Ug));
    ok = ok && read_all(f, net->bg, sizeof(net->bg));
    ok = ok && read_all(f, net->Wy, sizeof(net->Wy));
    ok = ok && read_all(f, net->by, sizeof(net->by));

    fclose(f);

    if (ok) {
        net->weights_loaded = true;
        HAL_Log("[LSTM] Loaded trained weights from '%s'", filepath);
    } else {
        HAL_Log("[LSTM] Truncated/corrupt weight file '%s' — rejecting",
                filepath);
    }
    return ok;
}
