/* ============================================================
   FILE: tms_fault.c
   EV Thermal Management — Fault Handling & Diagnostics
   v1.1.0: split out of the original combined
   "fault handling and diagnosis.c" (which also contained main());
   main() now lives in main.c. Uses HAL_Log/HAL_StoreDTC/
   HAL_SetFaultIndicator instead of printf.
   ============================================================ */

#include "ev_tms.h"

/* ── Fault Checker ───────────────────────────────────────── */
void TMS_CheckFaults(TMSController_t *tms)
{
    ThermalState_t *ts = &tms->thermal_state;
    SensorData_t   *s  = &tms->sensors;

    if (ts->T_batt_max >= BATT_TEMP_CRITICAL)
        tms->fault_flags |= FAULT_BATT_OVERHEAT;

    if (ts->T_motor >= MOTOR_TEMP_CRITICAL)
        tms->fault_flags |= FAULT_MOTOR_OVERHEAT;

    if (ts->T_inverter >= INV_TEMP_CRITICAL)
        tms->fault_flags |= FAULT_INV_OVERHEAT;

    if (ts->T_batt_max >= BATT_TEMP_RUNAWAY)
        tms->fault_flags |= FAULT_THERMAL_RUNAWAY;

    for (int i = 0; i < NUM_FLOW_SENSORS; i++) {
        if (s->flow_rate[i] < 2.0f)
            tms->fault_flags |= FAULT_COOLANT_LOW_FLOW;
    }

    HAL_SetFaultIndicator(tms->fault_flags != FAULT_NONE);

    if (tms->fault_flags != FAULT_NONE) {
        HAL_StoreDTC((uint32_t)tms->fault_flags);
        TMS_HandleFault(tms, tms->fault_flags);
    }
}

/* ── Fault Handler ───────────────────────────────────────── */
void TMS_HandleFault(TMSController_t *tms, FaultCode_t fault)
{
    if (fault & FAULT_THERMAL_RUNAWAY) {
        HAL_Log("[FAULT 0x%02X] THERMAL RUNAWAY - Emergency stop!", fault);
        tms->current_mode = MODE_THERMAL_RUNAWAY;
        TMS_ExecuteMode(tms);
        return;
    }

    if (fault & FAULT_BATT_OVERHEAT) {
        HAL_Log("[FAULT 0x%02X] Battery overheat - Max cooling!", fault);
        tms->actuator_cmd.pump_speed[0]    = 255;
        tms->actuator_cmd.chiller_enable   = true;
        tms->actuator_cmd.compressor_speed = 255;
        tms->actuator_cmd.fan_speed        = 255;
    }

    if (fault & FAULT_MOTOR_OVERHEAT) {
        HAL_Log("[FAULT 0x%02X] Motor overheat!", fault);
        tms->actuator_cmd.pump_speed[1] = 255;
        tms->actuator_cmd.fan_speed     = 255;
    }

    if (fault & FAULT_COOLANT_LOW_FLOW) {
        HAL_Log("[FAULT 0x%02X] Low coolant flow!", fault);
        tms->actuator_cmd.pump_speed[0] = 255;
        tms->actuator_cmd.pump_speed[1] = 255;
    }

    if (fault & FAULT_SENSOR_FAILURE) {
        HAL_Log("[FAULT 0x%02X] Sensor failure - using estimates", fault);
    }

    TMS_ApplyActuators(tms);
}

/* ── Safe Shutdown ───────────────────────────────────────── */
void TMS_SafeShutdown(TMSController_t *tms)
{
    HAL_Log("[TMS] Safe shutdown initiated.");
    tms->actuator_cmd.heat_pump_enable  = false;
    tms->actuator_cmd.chiller_enable    = false;
    tms->actuator_cmd.compressor_speed  = 0;
    /* Keep pumps and fans running for emergency cooling */
    tms->actuator_cmd.pump_speed[0]     = 255;
    tms->actuator_cmd.pump_speed[1]     = 255;
    tms->actuator_cmd.fan_speed         = 255;
}

/* ── Print Diagnostics ───────────────────────────────────── */
void TMS_PrintDiagnostics(const TMSController_t *tms)
{
    const ThermalState_t *ts  = &tms->thermal_state;
    const ActuatorCmd_t  *cmd = &tms->actuator_cmd;

    HAL_Log("======================================");
    HAL_Log("  EV TMS DIAGNOSTICS  |  t = %u ms", tms->uptime_ms);
    HAL_Log("======================================");
    HAL_Log("  MODE      : %d", tms->current_mode);
    HAL_Log("  FAULTS    : 0x%02X", tms->fault_flags);
    HAL_Log("  T_batt_avg: %6.2f C  (max: %6.2f C)",
            ts->T_batt_avg, ts->T_batt_max);
    HAL_Log("  T_motor   : %6.2f C", ts->T_motor);
    HAL_Log("  T_inverter: %6.2f C", ts->T_inverter);
    HAL_Log("  T_cabin   : %6.2f C", ts->T_cabin);
    HAL_Log("  T_coolant : in=%.1fC  out=%.1fC",
            ts->T_coolant_in, ts->T_coolant_out);
    HAL_Log("  Q_batt    : %6.2f W", ts->Q_batt_gen);
    HAL_Log("  Q_motor   : %6.2f W", ts->Q_motor_gen);
    HAL_Log("  Q_inv     : %6.2f W", ts->Q_inv_gen);
    HAL_Log("  PREDICTED (%ds): batt=%.1f motor=%.1f inv=%.1f cabin=%.1f%s",
            PRED_HORIZON, tms->T_batt_pred, tms->T_motor_pred,
            tms->T_inv_pred, tms->T_cabin_pred,
            tms->lstm_primed ? "" : "  [WARMING UP]");
    HAL_Log("  Pump0=%3d  Pump1=%3d  Fan=%3d  Comp=%3d",
            cmd->pump_speed[0], cmd->pump_speed[1],
            cmd->fan_speed, cmd->compressor_speed);
    HAL_Log("  HeatPump=%d  Chiller=%d  Immersion=%d",
            cmd->heat_pump_enable, cmd->chiller_enable,
            cmd->immersion_trigger);
    HAL_Log("======================================\n");
}
