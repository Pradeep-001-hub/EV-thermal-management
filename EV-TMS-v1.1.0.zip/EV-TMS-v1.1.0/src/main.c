/* ============================================================
   FILE: main.c
   EV Thermal Management — Control Loop Entry Point
   v1.1.0: split out of the original fault-handling file so main()
   isn't buried inside a diagnostics module.

   Host build:  runs a 1000-cycle (100s) simulated drive cycle.
   Target build: TODO — replace the fixed-iteration for-loop with
     your RTOS task loop (or bare SysTick-scheduled loop) that
     runs forever at CONTROL_PERIOD_MS cadence.
   ============================================================ */

#include "ev_tms.h"

int main(void)
{
    TMSController_t tms;

    TMS_Init(&tms);

    HAL_Log("[TMS] Starting control loop...\n");

#ifdef TARGET_HOST
    const uint32_t NUM_CYCLES = 1000;  /* 100s @ 100ms period, host demo only */
#endif

#ifdef TARGET_HOST
    for (uint32_t cycle = 0; cycle < NUM_CYCLES; cycle++) {
#else
    for (;;) {  /* TODO: on target, gate this on a SysTick/RTOS
                   periodic wake-up at CONTROL_PERIOD_MS instead
                   of spinning free-running. */
#endif
        HAL_DelayMs(CONTROL_PERIOD_MS);
        tms.uptime_ms = HAL_GetTick();

        HAL_WatchdogFeed();

        TMS_ReadSensors(&tms);
        TMS_ValidateSensors(&tms);
        TMS_UpdateThermalState(&tms);
        TMS_UpdateSequenceBuffer(&tms);
        TMS_RunLSTMPrediction(&tms);
        tms.current_mode = TMS_DecideMode(&tms);
        TMS_ExecuteMode(&tms);
        TMS_CheckFaults(&tms);

        if ((tms.uptime_ms / CONTROL_PERIOD_MS) % 10 == 0)
            TMS_PrintDiagnostics(&tms);
    }

    HAL_Log("[TMS] Simulation complete.");
    return 0;
}
