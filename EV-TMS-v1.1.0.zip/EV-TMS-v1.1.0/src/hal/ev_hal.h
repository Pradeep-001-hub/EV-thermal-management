/* ============================================================
   FILE: ev_hal.h
   Hardware Abstraction Layer — EV Thermal Management System

   Purpose:
     The control/prediction/fault logic (tms_*.c) must never call
     printf, ADC drivers, CAN drivers, or PWM timers directly.
     Everything hardware- or platform-specific goes through this
     interface. This is what makes the same tms_control.c /
     tms_lstm.c / tms_fault.c compile and run identically on:

       - Host (Linux/macOS/Windows) for simulation & unit tests
         -> implemented in ev_hal_host.c (build with -DTARGET_HOST)

       - ARM Cortex-M target (STM32/automotive MCU)
         -> implemented in ev_hal_stm32.c (build with -DTARGET_ARM)
            NOTE: ev_hal_stm32.c is a porting STUB. The register-
            level ADC/CAN/PWM/flash code is chip-specific and must
            be filled in against your MCU's reference manual/HAL
            (e.g. STM32 HAL, or vendor SDK). Every function below
            has a TODO marking exactly what to implement.

   Two build targets select the backend at compile time; no
   function-pointer/vtable overhead, so this stays interrupt-
   and real-time-safe on the embedded side.
   ============================================================ */

#ifndef EV_HAL_H
#define EV_HAL_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

/* ── Lifecycle ────────────────────────────────────────────── */
void     HAL_Init(void);                 /* clocks, ADC, CAN, PWM, flash */
uint32_t HAL_GetTick(void);              /* milliseconds since boot */
void     HAL_DelayMs(uint32_t ms);
void     HAL_WatchdogFeed(void);         /* pet the IWDG/WWDG */

/* ── Raw sensor acquisition ─────────────────────────────────
   Returns physical units already scaled (°C, bar, L/min).
   On target: reads ADC channel + applies calibration curve, or
   parses the latest CAN/LIN frame for that signal.
   On host: returns a simulated drive-cycle value.
   ──────────────────────────────────────────────────────────*/
float HAL_ReadTempSensor(uint8_t channel);      /* 0..27 */
float HAL_ReadPressureSensor(uint8_t channel);  /* 0..5  */
float HAL_ReadFlowSensor(uint8_t channel);      /* 0..3  */
float HAL_ReadAmbientTemp(void);
float HAL_ReadAmbientHumidity(void);
float HAL_ReadSolarLoad(void);
float HAL_ReadVehicleSpeed(void);
float HAL_ReadBatteryCurrent(void);
float HAL_ReadBatteryVoltage(void);
float HAL_ReadSOC(void);
float HAL_ReadMotorPower(void);
float HAL_ReadChargePower(void);
float HAL_ReadGPSElevation(void);
float HAL_ReadGPSGrade(void);
float HAL_ReadWeatherForecastTemp(void); /* from telematics/CAN gateway */

/* ── Actuator output ─────────────────────────────────────────
   duty: 0-255 PWM duty cycle. state: valve open/closed/partial.
   On target: writes timer compare register / GPIO / CAN command
   frame to the valve/pump/compressor driver module.
   ──────────────────────────────────────────────────────────*/
void HAL_SetValve(uint8_t valve_idx, uint8_t state_or_duty);
void HAL_SetPumpSpeed(uint8_t pump_idx, uint8_t duty);
void HAL_SetCompressorSpeed(uint8_t duty);
void HAL_SetFanSpeed(uint8_t duty);
void HAL_SetPeltierDuty(uint8_t duty);
void HAL_SetHeatPumpEnable(bool enable);
void HAL_SetChillerEnable(bool enable);
void HAL_TriggerImmersionCooling(void); /* latches until HAL_Init/reset */

/* ── Non-volatile storage (LSTM weights, calibration) ────────
   On target: reads/writes from external flash / internal flash
   sector reserved for calibration data (memory-mapped or via
   flash driver — see ev_hal_stm32.c TODOs).
   On host: reads/writes an ordinary file.
   ──────────────────────────────────────────────────────────*/
bool HAL_StorageRead(const char *key, void *buf, size_t len);
bool HAL_StorageWrite(const char *key, const void *buf, size_t len);

/* ── Logging (compiled out entirely on target release builds) */
void HAL_Log(const char *fmt, ...);

/* ── Fault/diagnostic output (dashboard warning lamp, DTC, etc) */
void HAL_SetFaultIndicator(bool active);
void HAL_StoreDTC(uint32_t fault_code);

#endif /* EV_HAL_H */
