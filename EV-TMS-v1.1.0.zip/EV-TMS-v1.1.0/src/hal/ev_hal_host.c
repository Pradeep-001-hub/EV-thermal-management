/* ============================================================
   FILE: ev_hal_host.c
   HAL backend: Host simulation (Linux/macOS/Windows)
   Build with -DTARGET_HOST

   Reproduces the original drive-cycle simulation so the exact
   same tms_*.c control logic can be unit-tested and demoed on a
   desktop before flashing to hardware.
   ============================================================ */
#include "ev_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

static uint32_t s_tick_ms = 0;
static bool     s_immersion_latched = false;
static bool     s_fault_indicator = false;

/* cached per-tick simulated state, recomputed once per HAL_Init/tick */
static float s_t = 0.0f;

void HAL_Init(void)
{
    s_tick_ms = 0;
    s_immersion_latched = false;
    s_fault_indicator = false;
    srand(42);
}

uint32_t HAL_GetTick(void)
{
    return s_tick_ms;
}

void HAL_DelayMs(uint32_t ms)
{
    /* Host sim: just advance the virtual clock; caller drives cadence */
    s_tick_ms += ms;
    s_t = (float)s_tick_ms / 1000.0f;
}

void HAL_WatchdogFeed(void) { /* no-op on host */ }

float HAL_ReadTempSensor(uint8_t channel)
{
    float t = s_t;
    float batt_avg = 25.0f + 0.003f * t + 5.0f * sinf(t / 300.0f);
    switch (channel) {
        case 0: return batt_avg;                       /* T_batt_avg */
        case 1: return batt_avg + 3.0f;                 /* T_batt_max */
        case 2: return batt_avg - 2.0f;                 /* T_batt_min */
        case 3: return 50.0f + 0.005f*t + 10.0f*sinf(t/200.0f); /* motor */
        case 4: return 60.0f + 0.004f*t + 8.0f*sinf(t/200.0f);  /* inv */
        case 5: return 22.0f + 2.0f*sinf(t/1000.0f);     /* cabin */
        case 6: return 30.0f + 0.002f*t;                 /* coolant in */
        case 7: return 30.0f + 0.002f*t + 8.0f;           /* coolant out */
        default: return batt_avg + (float)(channel - 8) * 0.5f;
    }
}

float HAL_ReadPressureSensor(uint8_t channel)
{
    (void)channel;
    return 2.5f + 0.1f * sinf(s_t / 100.0f);
}

float HAL_ReadFlowSensor(uint8_t channel)
{
    (void)channel;
    return 8.0f + sinf(s_t / 50.0f);
}

float HAL_ReadAmbientTemp(void)     { return 28.0f + 5.0f * sinf(s_t / 3600.0f); }
float HAL_ReadAmbientHumidity(void) { return 50.0f; }
float HAL_ReadSolarLoad(void)       { return 400.0f * fmaxf(0.0f, sinf(s_t / 43200.0f)); }
float HAL_ReadVehicleSpeed(void)    { return 60.0f + 30.0f * sinf(s_t / 500.0f); }
float HAL_ReadBatteryCurrent(void)  { return 80.0f + 20.0f * sinf(s_t / 300.0f); }
float HAL_ReadBatteryVoltage(void)  { return 380.0f - 0.001f * s_t; }

float HAL_ReadSOC(void)
{
    float soc = 1.0f - 0.00002f * s_t;
    return soc < 0.05f ? 0.05f : soc;
}

float HAL_ReadMotorPower(void)      { return HAL_ReadVehicleSpeed() * 0.25f; }
float HAL_ReadChargePower(void)     { return 0.0f; }
float HAL_ReadGPSElevation(void)    { return 200.0f + 50.0f * sinf(s_t / 600.0f); }
float HAL_ReadGPSGrade(void)        { return 2.0f * sinf(s_t / 300.0f); }
float HAL_ReadWeatherForecastTemp(void) { return HAL_ReadAmbientTemp() + 2.0f; }

void HAL_SetValve(uint8_t valve_idx, uint8_t state_or_duty)
{ (void)valve_idx; (void)state_or_duty; /* host: no physical valve */ }

void HAL_SetPumpSpeed(uint8_t pump_idx, uint8_t duty)
{ (void)pump_idx; (void)duty; }

void HAL_SetCompressorSpeed(uint8_t duty) { (void)duty; }
void HAL_SetFanSpeed(uint8_t duty)        { (void)duty; }
void HAL_SetPeltierDuty(uint8_t duty)     { (void)duty; }
void HAL_SetHeatPumpEnable(bool enable)   { (void)enable; }
void HAL_SetChillerEnable(bool enable)    { (void)enable; }

void HAL_TriggerImmersionCooling(void)
{
    s_immersion_latched = true;
    HAL_Log("[HAL] *** IMMERSION COOLING TRIGGERED ***");
}

bool HAL_StorageRead(const char *key, void *buf, size_t len)
{
    FILE *f = fopen(key, "rb");
    if (!f) return false;
    size_t n = fread(buf, 1, len, f);
    fclose(f);
    return n == len;
}

bool HAL_StorageWrite(const char *key, const void *buf, size_t len)
{
    FILE *f = fopen(key, "wb");
    if (!f) return false;
    size_t n = fwrite(buf, 1, len, f);
    fclose(f);
    return n == len;
}

void HAL_Log(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    printf("\n");
}

void HAL_SetFaultIndicator(bool active) { s_fault_indicator = active; }
void HAL_StoreDTC(uint32_t fault_code)  { (void)fault_code; }
