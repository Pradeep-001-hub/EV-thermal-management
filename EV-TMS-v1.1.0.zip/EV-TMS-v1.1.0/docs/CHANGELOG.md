# Changelog

## v1.1.0

**Goal of this pass: real embedded deployability (Cortex-M target),
starting from the v1.0.0 host-only simulation.**

### Bugs fixed
- `TMS_PIDUpdate()`: divided by `pid->Ki` before checking `Ki > 0`,
  causing NaN/Inf when a controller was configured with `Ki == 0`.
  Guard added before the division; integral accumulator is reset to 0
  when `Ki == 0` so a later gain change doesn't inherit stale windup.
- `TMS_RunLSTMPrediction()`: reset LSTM state and replayed all 60
  buffered timesteps through `LSTM_Forward()` **every single 100ms
  control cycle** — 60x the necessary matmul work per cycle. Replaced
  with stateful streaming inference: one `LSTM_Forward()` call per new
  sample, state carried across cycles (reset only at init). O(1)
  instead of O(SEQ_LENGTH) per cycle. `tools/train_lstm.py` trains the
  network the same way (stateful truncated-BPTT) so training and
  inference behavior match.
- Magic array indices (`s->temperature[0]`, `[3]`, `[6]`, etc.)
  replaced with named enums (`TS_BATT_AVG`, `FEAT_T_MOTOR`, ...) in
  `ev_tms.h` — same behavior, far less fragile to reorder.

### Added
- **HAL abstraction layer** (`src/hal/`): all sensor reads and
  actuator writes now go through `HAL_*` functions instead of being
  hardcoded/simulated inline in the control code or written but never
  applied. Two backends: `ev_hal_host.c` (tested, used for `make host`
  / `make test`) and `ev_hal_stm32.c` (porting template — see
  `docs/PORTING.md`).
- **`TMS_ApplyActuators()`**: previously `TMS_SetValves`/`TMS_SetPumps`
  only wrote to the in-memory `ActuatorCmd_t` struct — nothing
  actually drove hardware. Now called once per cycle to push commands
  through the HAL.
- **`TMS_LoadLSTMWeights()` / `TMS_SaveLSTMWeights()`**: implemented
  (previously declared, never implemented or called). Binary format is
  field-by-field (not a raw struct dump), independent of compiler
  struct padding. `TMS_Init()` now tries to load real weights first,
  falls back to the old random init (clearly logged) only if no
  weight file is present.
- **`tools/train_lstm.py`**: pure-NumPy LSTM training pipeline
  (no TensorFlow/PyTorch dependency). Generates synthetic multi-
  scenario drive-cycle data (normal / fast-charge / cold-start /
  hot-climate — v1.0.0's simulation only ever produced "normal drive"
  data, which gave the LSTM nothing to learn from even in principle).
  Trains with hand-derived, gradient-checked BPTT matching the C
  `LSTM_Forward()` gate equations exactly, exports weights in the
  format `TMS_LoadLSTMWeights()` reads.
- **`tests/test_tms.c`**: 25 unit tests covering PID edge cases,
  activation function sanity, mode-decision priority ordering, fault
  detection thresholds, and weight save/load round-tripping. Runs on
  host via `make test`.
- **`Makefile`**: `make host`, `make test`, `make run`, and a
  scaffolded (untested — no ARM toolchain available while writing
  this) `make arm` cross-build target.
- **`build/linker/stm32_template.ld`, `build/startup/startup_stub.c`**:
  generic Cortex-M linker script and startup code skeleton.
- **`docs/PORTING.md`**: step-by-step guide for finishing the port to
  a real MCU.
- `weights_loaded` flag on `LSTMNetwork_t` and `lstm_primed` flag on
  `TMSController_t` so the system can tell (and log, and gate
  predictive-mode decisions on) whether it's running trained weights
  and whether the prediction window has actually filled up, instead
  of silently emitting meaningless predictions during warm-up as
  v1.0.0 did.

### Known still-open items (see `docs/PORTING.md`)
- `ev_hal_stm32.c` is a template, not a finished driver — every
  function needs chip-specific register/HAL calls filled in.
- No functional-safety (ISO 26262) process has been applied to this
  codebase. Do not connect real actuators without independent review.
- `Q_inv_gen` heat model still uses a simplified I²R proxy rather than
  a real SiC switching-loss model (flagged in `tms_sensors.c`, not
  fixed — needs datasheet-level Vds/Id/fsw curves for the actual
  module in use).
