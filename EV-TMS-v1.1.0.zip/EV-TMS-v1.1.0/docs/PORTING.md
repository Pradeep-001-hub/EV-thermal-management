# Porting Guide — Deploying to a Real Cortex-M Target

This codebase is split so that **all hardware-specific code lives behind
`src/hal/ev_hal.h`**. `src/tms_*.c` (sensor processing, LSTM inference,
mode decision, fault handling) never touches a register, ADC, CAN
peripheral, or `printf` directly — it only calls `HAL_*` functions.
That's what lets the exact same control logic run — and be
unit-tested — on a desktop, and then be ported to silicon by filling in
one file: `src/hal/ev_hal_stm32.c`.

## What's already done
- `src/hal/ev_hal_host.c` — full simulation backend, used by `make host`
  and `make test`. This is what's been built and tested in this repo.
- `src/hal/ev_hal_stm32.c` — porting **template**. Every function has
  the correct signature and a `TODO` comment describing exactly what
  register/peripheral call belongs there.
- `build/linker/stm32_template.ld` and `build/startup/startup_stub.c` —
  generic Cortex-M skeleton (vector table shape, reset handler,
  data/bss init). Not chip-specific.

## What you still need to do (in order)

1. **Pick your exact MCU** and get its CMSIS device pack / vendor HAL
   (e.g. STM32Cube for ST parts). Automotive-grade candidates: STM32
   with FDCAN, or NXP S32K, or Infineon TC3xx (AURIX) for ASIL-rated
   designs — this template assumes an STM32-style HAL API, adjust
   accordingly for other vendors.

2. **Replace the linker script and startup file** with your vendor's
   generated ones (from STM32CubeMX or your SDK) — the ones here are
   generic placeholders, not tuned to a real flash/RAM map or full IRQ
   vector table.

3. **Fill in `ev_hal_stm32.c`** function by function:
   - `HAL_Init()` — clock tree, GPIO, ADC, CAN, timers/PWM, watchdog
   - `HAL_ReadTempSensor()` / pressure / flow — either ADC + calibration
     curve for directly-wired NTC/pressure sensors, or a CAN-RX-ISR
     cache lookup if a separate sensor-interface module publishes them
     on the bus (see `docs/System architecture design/` for the CAN ID
     map you'll need to define against the "Sensor Network and Data
     Flow" doc's 28 temp / 6 pressure / 4 flow sensor list)
   - `HAL_Set*` actuator functions — PWM timer compare registers or
     CAN command frames to the valve/pump/compressor driver modules
   - `HAL_StorageRead/Write` — reserved flash sector for
     `lstm_weights.bin`'s contents (see step 5)
   - `HAL_TriggerImmersionCooling()` — this is safety-critical; wire it
     to a dedicated fail-safe GPIO, not shared with anything else

4. **Verify timing budget.** `TMS_RunLSTMPrediction()` now does one
   `LSTM_Forward()` call per 100ms cycle (64 hidden units × 15
   features + 64×64 recurrent matmuls — roughly 64×(15+64)×4 ≈ 20k
   multiply-adds per gate × 4 gates ≈ 80k MACs). On a 100+ MHz
   Cortex-M4 with hardware FPU this should comfortably fit inside a
   100ms period, but measure it on your actual target before trusting
   the control loop timing — don't assume.

5. **Deploy trained weights.** Run `tools/train_lstm.py` (see its own
   docstring) to produce `lstm_weights.bin`, then flash its contents
   into the flash sector `HAL_StorageRead("lstm_weights.bin", ...)`
   reads from — either as part of your firmware image (embed as a
   `const` array via `xxd -i` / `objcopy`) or as a separate
   calibration-flash write step, whichever fits your release process.
   **Do not ship with the random/untrained fallback weights** —
   `TMS_Init()` logs a warning and predictions are physically
   meaningless in that case (see main README).

6. **Build:** `make arm` (after pointing `ARM_CC`/`ARM_CPU` in the
   Makefile at your toolchain/core — this repo was written without an
   ARM cross-compiler available, so this target is scaffolded but has
   not been compiled here).

7. **Safety review before any real hardware activation.** This
   project has not gone through any functional-safety process
   (ISO 26262 or similar). At minimum, before enabling
   `HAL_TriggerImmersionCooling()` or any real actuator on a vehicle:
   independent review of the fault/mode-decision logic, a hardware
   watchdog that can force a safe state independent of this firmware,
   and bench testing with actuators disconnected before connecting to
   real coolant/refrigerant hardware.
